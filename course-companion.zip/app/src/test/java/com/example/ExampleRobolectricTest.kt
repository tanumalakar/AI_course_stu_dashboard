package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AssignmentStatus
import com.example.data.model.ClassStatus
import com.example.data.repository.InMemoryCourseRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Course Companion", appName)
    }

    @Test
    fun `verify both required batches exist in repository`() = runBlocking {
        val repository = InMemoryCourseRepository()
        val batches = repository.getBatches().first()

        assertEquals(2, batches.size)

        val aiBatch = batches.find { it.id == "ai-uses" }
        assertNotNull(aiBatch)
        assertEquals("Artificial Intelligence Uses", aiBatch?.title)
        assertTrue(aiBatch?.description?.isNotEmpty() == true)
        assertTrue(aiBatch?.scheduleDays?.isNotEmpty() == true)
        assertTrue(aiBatch?.timing?.isNotEmpty() == true)

        val freelancingBatch = batches.find { it.id == "freelancing" }
        assertNotNull(freelancingBatch)
        assertEquals("Freelancing", freelancingBatch?.title)
        assertTrue(freelancingBatch?.description?.isNotEmpty() == true)
        assertTrue(freelancingBatch?.scheduleDays?.isNotEmpty() == true)
        assertTrue(freelancingBatch?.timing?.isNotEmpty() == true)
    }

    @Test
    fun `verify batch specific classes resources assignments and announcements`() = runBlocking {
        val repository = InMemoryCourseRepository()

        val aiClasses = repository.getClasses("ai-uses").first()
        assertTrue(aiClasses.isNotEmpty())
        assertTrue(aiClasses.all { it.batchId == "ai-uses" })

        val freelanceClasses = repository.getClasses("freelancing").first()
        assertTrue(freelanceClasses.isNotEmpty())
        assertTrue(freelanceClasses.all { it.batchId == "freelancing" })

        val aiMaterials = repository.getMaterials("ai-uses").first()
        assertTrue(aiMaterials.isNotEmpty())
        assertTrue(aiMaterials.all { it.batchId == "ai-uses" })

        val freelanceMaterials = repository.getMaterials("freelancing").first()
        assertTrue(freelanceMaterials.isNotEmpty())
        assertTrue(freelanceMaterials.all { it.batchId == "freelancing" })

        val aiAssignments = repository.getAssignments("ai-uses").first()
        assertTrue(aiAssignments.isNotEmpty())
        assertTrue(aiAssignments.all { it.batchId == "ai-uses" })

        val freelanceAssignments = repository.getAssignments("freelancing").first()
        assertTrue(freelanceAssignments.isNotEmpty())
        assertTrue(freelanceAssignments.all { it.batchId == "freelancing" })

        val announcements = repository.getAnnouncements().first()
        assertTrue(announcements.size >= 4)
    }

    @Test
    fun `verify assignment submission updates status`() = runBlocking {
        val repository = InMemoryCourseRepository()
        val initialAssignments = repository.getAssignments().first()
        val pendingAssignment = initialAssignments.first { it.status == AssignmentStatus.PENDING }

        repository.submitAssignment(pendingAssignment.id, "https://github.com/alex/ai-agent-project")

        val updatedAssignments = repository.getAssignments().first()
        val submitted = updatedAssignments.first { it.id == pendingAssignment.id }
        assertEquals(AssignmentStatus.SUBMITTED, submitted.status)
        assertEquals("https://github.com/alex/ai-agent-project", submitted.submissionText)
    }
}
