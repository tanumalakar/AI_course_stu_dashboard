package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MaterialItem
import com.example.data.model.MaterialType
import com.example.ui.components.MaterialItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialsScreen(
    viewModel: CourseViewModel,
    modifier: Modifier = Modifier
) {
    val materials by viewModel.materials.collectAsState()
    val batchFilter by viewModel.selectedBatchFilter.collectAsState()
    val typeFilter by viewModel.materialTypeFilter.collectAsState()
    val searchQuery by viewModel.materialSearchQuery.collectAsState()

    val filteredMaterials = remember(materials, batchFilter, typeFilter, searchQuery) {
        materials.filter { mat ->
            val matchBatch = when (batchFilter) {
                "ai-uses" -> mat.batchId == "ai-uses"
                "freelancing" -> mat.batchId == "freelancing"
                else -> true
            }
            val matchType = typeFilter == null || mat.type == typeFilter
            val matchSearch = searchQuery.isBlank() ||
                mat.title.contains(searchQuery, ignoreCase = true) ||
                mat.description.contains(searchQuery, ignoreCase = true) ||
                mat.tags.any { it.contains(searchQuery, ignoreCase = true) }

            matchBatch && matchType && matchSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Course Materials",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setMaterialSearchQuery(it) },
                placeholder = { Text("Search materials, slide decks, templates...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextMuted
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setMaterialSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = BorderLight
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("material_search_input")
            )

            // Batch & Type Filters
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp)
            ) {
                // Batch filter
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = batchFilter == "all" || batchFilter == null,
                            onClick = { viewModel.setBatchFilter("all") },
                            label = { Text("All Batches", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "ai-uses",
                            onClick = { viewModel.setBatchFilter("ai-uses") },
                            label = { Text("AI Uses", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "freelancing",
                            onClick = { viewModel.setBatchFilter("freelancing") },
                            label = { Text("Freelancing", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                }

                // Type filter
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = typeFilter == null,
                            onClick = { viewModel.setMaterialTypeFilter(null) },
                            label = { Text("All Types", fontSize = 11.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    MaterialType.values().forEach { type ->
                        item {
                            FilterChip(
                                selected = typeFilter == type,
                                onClick = { viewModel.setMaterialTypeFilter(type) },
                                label = { Text(type.name, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Materials List
            if (filteredMaterials.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No learning materials found.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = 24.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("materials_list")
                ) {
                    items(filteredMaterials, key = { it.id }) { mat ->
                        MaterialItemCard(
                            material = mat,
                            onViewClick = { viewModel.openMaterialViewer(mat) }
                        )
                    }
                }
            }
        }
    }
}
