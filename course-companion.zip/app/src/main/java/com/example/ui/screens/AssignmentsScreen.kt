package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Task
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssignmentStatus
import com.example.ui.components.AssignmentItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignmentsScreen(
    viewModel: CourseViewModel,
    modifier: Modifier = Modifier
) {
    val assignments by viewModel.assignments.collectAsState()
    val batchFilter by viewModel.selectedBatchFilter.collectAsState()
    val statusFilter by viewModel.assignmentStatusFilter.collectAsState()

    val filteredAssignments = remember(assignments, batchFilter, statusFilter) {
        assignments.filter { asg ->
            val matchBatch = when (batchFilter) {
                "ai-uses" -> asg.batchId == "ai-uses"
                "freelancing" -> asg.batchId == "freelancing"
                else -> true
            }
            val matchStatus = statusFilter == null || asg.status == statusFilter
            matchBatch && matchStatus
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Assignment,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Course Assignments",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Filters
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                // Batch Filter Pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = batchFilter == "all" || batchFilter == null,
                            onClick = { viewModel.setBatchFilter("all") },
                            label = { Text("All Batches", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "ai-uses",
                            onClick = { viewModel.setBatchFilter("ai-uses") },
                            label = { Text("AI Uses", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "freelancing",
                            onClick = { viewModel.setBatchFilter("freelancing") },
                            label = { Text("Freelancing", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                }

                // Status Filter Segment
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = statusFilter == null,
                            onClick = { viewModel.setAssignmentStatusFilter(null) },
                            label = { Text("All Status", fontSize = 11.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    AssignmentStatus.values().forEach { status ->
                        item {
                            FilterChip(
                                selected = statusFilter == status,
                                onClick = { viewModel.setAssignmentStatusFilter(status) },
                                label = { Text(status.name, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Assignments List
            if (filteredAssignments.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Task,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No assignments match your criteria.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = 24.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("assignments_list")
                ) {
                    items(filteredAssignments, key = { it.id }) { asg ->
                        AssignmentItemCard(
                            assignment = asg,
                            onSubmitClick = { viewModel.openSubmitAssignmentDialog(asg) }
                        )
                    }
                }
            }
        }
    }
}
