package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnnouncementItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnnouncementsScreen(
    viewModel: CourseViewModel,
    modifier: Modifier = Modifier
) {
    val announcements by viewModel.announcements.collectAsState()
    val batchFilter by viewModel.selectedBatchFilter.collectAsState()

    val filteredAnnouncements = remember(announcements, batchFilter) {
        announcements.filter { ann ->
            when (batchFilter) {
                "ai-uses" -> ann.batchId == null || ann.batchId == "ai-uses"
                "freelancing" -> ann.batchId == null || ann.batchId == "freelancing"
                else -> true
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Course Announcements",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Batch Filter Pills
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = batchFilter == "all" || batchFilter == null,
                        onClick = { viewModel.setBatchFilter("all") },
                        label = { Text("All Batches", fontSize = 12.sp) },
                        shape = RoundedCornerShape(100.dp)
                    )
                }
                item {
                    FilterChip(
                        selected = batchFilter == "ai-uses",
                        onClick = { viewModel.setBatchFilter("ai-uses") },
                        label = { Text("AI Uses", fontSize = 12.sp) },
                        shape = RoundedCornerShape(100.dp)
                    )
                }
                item {
                    FilterChip(
                        selected = batchFilter == "freelancing",
                        onClick = { viewModel.setBatchFilter("freelancing") },
                        label = { Text("Freelancing", fontSize = 12.sp) },
                        shape = RoundedCornerShape(100.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (filteredAnnouncements.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No announcements at this time.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = 24.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("announcements_list")
                ) {
                    items(filteredAnnouncements, key = { it.id }) { ann ->
                        AnnouncementItemCard(announcement = ann)
                    }
                }
            }
        }
    }
}
