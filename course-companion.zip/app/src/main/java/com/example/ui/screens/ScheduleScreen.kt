package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClassStatus
import com.example.data.model.CourseClass
import com.example.ui.components.ClassScheduleCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    viewModel: CourseViewModel,
    modifier: Modifier = Modifier
) {
    val classes by viewModel.classes.collectAsState()
    val batchFilter by viewModel.selectedBatchFilter.collectAsState()
    val statusFilter by viewModel.scheduleFilter.collectAsState()

    val filteredClasses = remember(classes, batchFilter, statusFilter) {
        classes.filter { cls ->
            val matchBatch = when (batchFilter) {
                "ai-uses" -> cls.batchId == "ai-uses"
                "freelancing" -> cls.batchId == "freelancing"
                else -> true
            }
            val matchStatus = when (statusFilter) {
                "UPCOMING" -> cls.status == ClassStatus.UPCOMING || cls.status == ClassStatus.LIVE_NOW
                "COMPLETED" -> cls.status == ClassStatus.COMPLETED
                else -> true
            }
            matchBatch && matchStatus
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Class Schedule",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Filter Rows
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                // Batch Filter Pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = batchFilter == "all" || batchFilter == null,
                            onClick = { viewModel.setBatchFilter("all") },
                            label = { Text("All Batches", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "ai-uses",
                            onClick = { viewModel.setBatchFilter("ai-uses") },
                            label = { Text("AI Uses", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = batchFilter == "freelancing",
                            onClick = { viewModel.setBatchFilter("freelancing") },
                            label = { Text("Freelancing", fontSize = 12.sp) },
                            shape = RoundedCornerShape(100.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Status Filter Segmented Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val statusOptions = listOf(
                        "ALL" to "All Classes",
                        "UPCOMING" to "Live & Upcoming",
                        "COMPLETED" to "Completed"
                    )

                    statusOptions.forEach { (key, label) ->
                        val isSelected = statusFilter == key
                        Surface(
                            color = if (isSelected) PrimaryBlue else SurfaceCardVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp),
                            onClick = { viewModel.setScheduleFilter(key) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = label,
                                    color = if (isSelected) androidx.compose.ui.graphics.Color.White else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Class List
            if (filteredClasses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No sessions found for this filter.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = 24.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("schedule_list")
                ) {
                    items(filteredClasses, key = { it.id }) { cls ->
                        ClassScheduleCard(
                            courseClass = cls,
                            onClassClick = { viewModel.openClassDetails(cls) }
                        )
                    }
                }
            }
        }
    }
}
