package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel

enum class BatchTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    OVERVIEW("Overview", Icons.Default.Info),
    SCHEDULE("Schedule", Icons.Default.CalendarMonth),
    RESOURCES("Resources", Icons.Default.Folder),
    ASSIGNMENTS("Assignments", Icons.Default.Assignment),
    ANNOUNCEMENTS("Announcements", Icons.Default.Campaign)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchDashboardScreen(
    batchId: String,
    viewModel: CourseViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val batches by viewModel.batches.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val materials by viewModel.materials.collectAsState()
    val assignments by viewModel.assignments.collectAsState()
    val announcements by viewModel.announcements.collectAsState()

    val batch = batches.find { it.id == batchId } ?: batches.firstOrNull()

    var selectedTab by remember { mutableStateOf(BatchTab.OVERVIEW) }

    val userProfile by viewModel.userProfile.collectAsState()
    val isEnrolled = batch != null && batch.id in userProfile.enrolledBatchIds

    val isAi = batchId == "ai-uses"

    val batchClasses = remember(classes, batchId) { classes.filter { it.batchId == batchId } }
    val upcomingClass = remember(batchClasses) {
        batchClasses.firstOrNull { it.status == ClassStatus.LIVE_NOW }
            ?: batchClasses.firstOrNull { it.status == ClassStatus.UPCOMING }
    }
    val batchMaterials = remember(materials, batchId) { materials.filter { it.batchId == batchId } }
    val batchAssignments = remember(assignments, batchId) { assignments.filter { it.batchId == batchId } }
    val batchAnnouncements = remember(announcements, batchId) { announcements.filter { it.batchId == null || it.batchId == batchId } }
    val toolsFlow = remember(batchId) { viewModel.getToolsForBatch(batchId) }
    val tools by toolsFlow.collectAsState(initial = emptyList())

    val gradientBrush = if (isAi) {
        Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF7C3AED)))
    } else {
        Brush.linearGradient(listOf(Color(0xFF059669), Color(0xFF0D9488)))
    }

    if (batch == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = batch.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        maxLines = 1,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("batch_dashboard_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "Syllabus downloaded for ${batch.title}", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FileDownload,
                            contentDescription = "Download Syllabus",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isAi) Color(0xFF4F46E5) else Color(0xFF059669)
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Hero Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(gradientBrush)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = CircleShape,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = batch.instructor,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = batch.instructorRole,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (isEnrolled) Color(0xFF10B981) else Color.White.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(100.dp),
                                modifier = Modifier.clickable { viewModel.toggleBatchEnrollment(batch.id) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isEnrolled) Icons.Default.Check else Icons.Default.Add,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isEnrolled) "Enrolled" else "Enroll",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(100.dp)
                            ) {
                                Text(
                                    text = "${batch.enrolledStudentsCount} Students",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Class Schedule",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                            Text(
                                text = batch.scheduleDays,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Class Timing",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                            Text(
                                text = batch.timing,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Batch Progress (${batch.completedClasses}/${batch.totalClasses} Completed)",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${(batch.progress * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { batch.progress },
                        color = Color.White,
                        trackColor = Color.White.copy(alpha = 0.3f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(CircleShape)
                    )
                }
            }

            // Sub-tabs (Overview, Schedule, Resources, Assignments, Announcements)
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = if (isAi) AiPurple else FreelanceGreen,
                divider = { HorizontalDivider(color = BorderLight) },
                modifier = Modifier.fillMaxWidth()
            ) {
                BatchTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = tab.title,
                                    fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    )
                }
            }

            // Tab Content
            AnimatedContent(
                targetState = selectedTab,
                label = "batch_tab_transition",
                modifier = Modifier.weight(1f)
            ) { currentTab ->
                when (currentTab) {
                    BatchTab.OVERVIEW -> {
                        BatchOverviewTab(
                            batch = batch,
                            upcomingClass = upcomingClass,
                            onClassClick = { viewModel.openClassDetails(it) },
                            onNavigateTab = { selectedTab = it }
                        )
                    }
                    BatchTab.SCHEDULE -> {
                        BatchScheduleTab(
                            classes = batchClasses,
                            onClassClick = { viewModel.openClassDetails(it) }
                        )
                    }
                    BatchTab.RESOURCES -> {
                        BatchResourcesTab(
                            materials = batchMaterials,
                            tools = tools,
                            onViewMaterial = { viewModel.openMaterialViewer(it) }
                        )
                    }
                    BatchTab.ASSIGNMENTS -> {
                        BatchAssignmentsTab(
                            assignments = batchAssignments,
                            onSubmitAssignment = { viewModel.openSubmitAssignmentDialog(it) }
                        )
                    }
                    BatchTab.ANNOUNCEMENTS -> {
                        BatchAnnouncementsTab(
                            announcements = batchAnnouncements
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BatchOverviewTab(
    batch: Batch,
    upcomingClass: CourseClass?,
    onClassClick: (CourseClass) -> Unit,
    onNavigateTab: (BatchTab) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Upcoming Class for this Batch
        if (upcomingClass != null) {
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Next Upcoming Class",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "View Schedule",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = PrimaryBlue,
                            modifier = Modifier
                                .clickable { onNavigateTab(BatchTab.SCHEDULE) }
                                .padding(4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    ClassScheduleCard(
                        courseClass = upcomingClass,
                        onClassClick = { onClassClick(upcomingClass) }
                    )
                }
            }
        }

        // Quick Navigation Grid
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Batch Sections",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickNavTile(
                            title = "Schedule",
                            subtitle = "${batch.totalClasses} Sessions",
                            icon = Icons.Default.CalendarMonth,
                            color = PrimaryBlue,
                            bgColor = PrimaryBlueContainer,
                            onClick = { onNavigateTab(BatchTab.SCHEDULE) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickNavTile(
                            title = "Resources",
                            subtitle = "Files & Tools",
                            icon = Icons.Default.Folder,
                            color = Color(0xFF0D9488),
                            bgColor = Color(0xFFCCFBF1),
                            onClick = { onNavigateTab(BatchTab.RESOURCES) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickNavTile(
                            title = "Assignments",
                            subtitle = "Tasks & Grades",
                            icon = Icons.Default.Assignment,
                            color = Color(0xFFD97706),
                            bgColor = Color(0xFFFEF3C7),
                            onClick = { onNavigateTab(BatchTab.ASSIGNMENTS) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickNavTile(
                            title = "Announcements",
                            subtitle = "Notices & Alerts",
                            icon = Icons.Default.Campaign,
                            color = Color(0xFF7C3AED),
                            bgColor = Color(0xFFEDE9FE),
                            onClick = { onNavigateTab(BatchTab.ANNOUNCEMENTS) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // About & Course Description
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "About This Course",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = batch.description,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = batch.syllabusOverview,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Curriculum & Core Modules
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Curriculum & Core Modules",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    batch.topics.forEachIndexed { index, topic ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Surface(
                                color = PrimaryBlueContainer,
                                shape = CircleShape,
                                modifier = Modifier.size(22.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${index + 1}",
                                        color = PrimaryBlue,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = topic,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // Tools & Software Covered
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Tools & Software Covered",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        batch.tools.take(3).forEach { tool ->
                            Surface(
                                color = SurfaceCardVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                ) {
                                    Text(
                                        text = tool,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickNavTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    bgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun BatchScheduleTab(
    classes: List<CourseClass>,
    onClassClick: (CourseClass) -> Unit
) {
    if (classes.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No classes scheduled yet for this batch.", color = TextMuted)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(classes) { cls ->
                ClassScheduleCard(
                    courseClass = cls,
                    onClassClick = { onClassClick(cls) }
                )
            }
        }
    }
}

@Composable
private fun BatchResourcesTab(
    materials: List<MaterialItem>,
    tools: List<ResourceTool>,
    onViewMaterial: (MaterialItem) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Study Materials & Class Notes
        item {
            Text(
                text = "Course Study Materials (${materials.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextPrimary
            )
        }

        if (materials.isEmpty()) {
            item {
                Surface(
                    color = SurfaceCardVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text("No materials uploaded yet.", color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(materials) { mat ->
                MaterialItemCard(
                    material = mat,
                    onViewClick = { onViewMaterial(mat) }
                )
            }
        }

        // Recommended Tools & Workspaces
        if (tools.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Recommended Software & Tools (${tools.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextPrimary
                )
            }

            items(tools) { tool ->
                ToolResourceCard(
                    tool = tool,
                    onOpenUrl = {
                        Toast.makeText(context, "Opening ${tool.name}...", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
private fun BatchAssignmentsTab(
    assignments: List<Assignment>,
    onSubmitAssignment: (Assignment) -> Unit
) {
    if (assignments.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No assignments active for this batch.", color = TextMuted)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(assignments) { asg ->
                AssignmentItemCard(
                    assignment = asg,
                    onSubmitClick = { onSubmitAssignment(asg) }
                )
            }
        }
    }
}

@Composable
private fun BatchAnnouncementsTab(
    announcements: List<Announcement>
) {
    if (announcements.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No announcements for this batch.", color = TextMuted)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(announcements) { ann ->
                AnnouncementItemCard(announcement = ann)
            }
        }
    }
}
