package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.CourseRepository
import com.example.data.repository.InMemoryCourseRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiMessage(
    val id: Long = System.currentTimeMillis(),
    val message: String
)

class CourseViewModel(
    private val repository: CourseRepository = InMemoryCourseRepository()
) : ViewModel() {

    val batches: StateFlow<List<Batch>> = repository.getBatches()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val classes: StateFlow<List<CourseClass>> = repository.getClasses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val materials: StateFlow<List<MaterialItem>> = repository.getMaterials()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assignments: StateFlow<List<Assignment>> = repository.getAssignments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<Announcement>> = repository.getAnnouncements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfile> = repository.getUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile())

    // UI State Filter selections
    private val _selectedBatchFilter = MutableStateFlow<String?>("all")
    val selectedBatchFilter: StateFlow<String?> = _selectedBatchFilter.asStateFlow()

    private val _materialTypeFilter = MutableStateFlow<MaterialType?>(null)
    val materialTypeFilter: StateFlow<MaterialType?> = _materialTypeFilter.asStateFlow()

    private val _materialSearchQuery = MutableStateFlow("")
    val materialSearchQuery: StateFlow<String> = _materialSearchQuery.asStateFlow()

    private val _assignmentStatusFilter = MutableStateFlow<AssignmentStatus?>(null)
    val assignmentStatusFilter: StateFlow<AssignmentStatus?> = _assignmentStatusFilter.asStateFlow()

    private val _scheduleFilter = MutableStateFlow("ALL") // "ALL", "UPCOMING", "COMPLETED"
    val scheduleFilter: StateFlow<String> = _scheduleFilter.asStateFlow()

    // Dialog & Interactive State
    private val _viewingMaterial = MutableStateFlow<MaterialItem?>(null)
    val viewingMaterial: StateFlow<MaterialItem?> = _viewingMaterial.asStateFlow()

    private val _submittingAssignment = MutableStateFlow<Assignment?>(null)
    val submittingAssignment: StateFlow<Assignment?> = _submittingAssignment.asStateFlow()

    private val _selectedClassDetails = MutableStateFlow<CourseClass?>(null)
    val selectedClassDetails: StateFlow<CourseClass?> = _selectedClassDetails.asStateFlow()

    private val _isEditProfileOpen = MutableStateFlow(false)
    val isEditProfileOpen: StateFlow<Boolean> = _isEditProfileOpen.asStateFlow()

    private val _uiMessages = MutableSharedFlow<UiMessage>()
    val uiMessages: SharedFlow<UiMessage> = _uiMessages.asSharedFlow()

    fun setBatchFilter(batchId: String?) {
        _selectedBatchFilter.value = batchId
    }

    fun setMaterialTypeFilter(type: MaterialType?) {
        _materialTypeFilter.value = type
    }

    fun setMaterialSearchQuery(query: String) {
        _materialSearchQuery.value = query
    }

    fun setAssignmentStatusFilter(status: AssignmentStatus?) {
        _assignmentStatusFilter.value = status
    }

    fun setScheduleFilter(filter: String) {
        _scheduleFilter.value = filter
    }

    fun openMaterialViewer(material: MaterialItem) {
        _viewingMaterial.value = material
    }

    fun closeMaterialViewer() {
        _viewingMaterial.value = null
    }

    fun openSubmitAssignmentDialog(assignment: Assignment) {
        _submittingAssignment.value = assignment
    }

    fun closeSubmitAssignmentDialog() {
        _submittingAssignment.value = null
    }

    fun openClassDetails(courseClass: CourseClass) {
        _selectedClassDetails.value = courseClass
    }

    fun closeClassDetails() {
        _selectedClassDetails.value = null
    }

    fun setEditProfileOpen(open: Boolean) {
        _isEditProfileOpen.value = open
    }

    fun submitAssignment(assignmentId: String, text: String) {
        viewModelScope.launch {
            repository.submitAssignment(assignmentId, text)
            _submittingAssignment.value = null
            _uiMessages.emit(UiMessage(message = "Assignment submitted successfully!"))
        }
    }

    fun toggleNotification(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleNotificationPreference(enabled)
            val msg = if (enabled) "Class reminders enabled" else "Reminders paused"
            _uiMessages.emit(UiMessage(message = msg))
        }
    }

    fun updateProfile(name: String, email: String, phone: String, bio: String, avatarColorIndex: Int = 0) {
        viewModelScope.launch {
            repository.updateProfile(name, email, phone, bio, avatarColorIndex)
            _isEditProfileOpen.value = false
            _uiMessages.emit(UiMessage(message = "Profile updated successfully!"))
        }
    }

    fun toggleBatchEnrollment(batchId: String) {
        viewModelScope.launch {
            repository.toggleBatchEnrollment(batchId)
            val currentEnrolled = userProfile.value.enrolledBatchIds
            val isNowEnrolled = batchId in currentEnrolled
            val msg = if (isNowEnrolled) "Enrolled in batch successfully!" else "Unenrolled from batch"
            _uiMessages.emit(UiMessage(message = msg))
        }
    }

    fun getToolsForBatch(batchId: String): Flow<List<ResourceTool>> {
        return repository.getResourceTools(batchId)
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CourseViewModel() as T
            }
        }
    }
}
