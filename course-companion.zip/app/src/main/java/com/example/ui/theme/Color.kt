package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand - Electric Indigo & Deep Royal
val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueDark = Color(0xFF1D4ED8)
val PrimaryBlueLight = Color(0xFF60A5FA)
val PrimaryBlueContainer = Color(0xFFEFF6FF)
val OnPrimaryBlueContainer = Color(0xFF1E3A8A)

// Secondary Brand - Slate Teal & Cyan Accent
val TealAccent = Color(0xFF0D9488)
val TealAccentLight = Color(0xFF2DD4BF)
val TealAccentContainer = Color(0xFFF0FDFA)
val OnTealContainer = Color(0xFF134E4A)

// Batch Specific Accent Colors
val AiPurple = Color(0xFF6366F1)
val AiPurpleDark = Color(0xFF4F46E5)
val AiPurpleContainer = Color(0xFFEEF2FF)
val OnAiPurpleContainer = Color(0xFF312E81)

val FreelanceGreen = Color(0xFF059669)
val FreelanceGreenDark = Color(0xFF047857)
val FreelanceGreenContainer = Color(0xFFECFDF5)
val OnFreelanceGreenContainer = Color(0xFF064E3B)

// Functional Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessBg = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusLive = Color(0xFFEF4444)
val StatusLiveBg = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF3B82F6)
val StatusInfoBg = Color(0xFFDBEAFE)

// Neutrals & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardVariant = Color(0xFFF1F5F9)
val BorderLight = Color(0xFFE2E8F0)
val BorderSubtle = Color(0xFFF1F5F9)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)
val TextDisabled = Color(0xFFCBD5E1)

// Dark Theme Variants
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF334155)

