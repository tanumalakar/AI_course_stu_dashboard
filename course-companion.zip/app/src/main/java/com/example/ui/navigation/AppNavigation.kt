package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.CourseViewModel
import kotlinx.coroutines.flow.collectLatest

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    data object Splash : Screen("splash", "Splash", Icons.Default.School, Icons.Outlined.School)
    data object Home : Screen("home", "Home", Icons.Default.Home, Icons.Outlined.Home)
    data object Schedule : Screen("schedule", "Schedule", Icons.Default.CalendarMonth, Icons.Outlined.CalendarMonth)
    data object Resources : Screen("resources", "Resources", Icons.Default.Folder, Icons.Outlined.Folder)
    data object Assignments : Screen("assignments", "Assignments", Icons.Default.Assignment, Icons.Outlined.Assignment)
    data object Announcements : Screen("announcements", "Announcements", Icons.Default.Campaign, Icons.Outlined.Campaign)
    data object Profile : Screen("profile", "Profile", Icons.Default.Person, Icons.Outlined.Person)
    data object BatchDashboard : Screen("batch/{batchId}", "Batch Dashboard", Icons.Default.School, Icons.Outlined.School) {
        fun createRoute(batchId: String) = "batch/$batchId"
    }
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Schedule,
    Screen.Resources,
    Screen.Announcements,
    Screen.Profile
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(
    viewModel: CourseViewModel,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val snackbarHostState = remember { SnackbarHostState() }

    val viewingMaterial by viewModel.viewingMaterial.collectAsState()
    val submittingAssignment by viewModel.submittingAssignment.collectAsState()
    val selectedClassDetails by viewModel.selectedClassDetails.collectAsState()
    val isEditProfileOpen by viewModel.isEditProfileOpen.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.uiMessages.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg.message)
        }
    }

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryBlue,
                                selectedTextColor = PrimaryBlue,
                                indicatorColor = PrimaryBlueContainer,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onSplashFinished = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToBatch = { batchId ->
                        navController.navigate(Screen.BatchDashboard.createRoute(batchId))
                    },
                    onNavigateToSchedule = {
                        navController.navigate(Screen.Schedule.route)
                    },
                    onNavigateToAnnouncements = {
                        navController.navigate(Screen.Announcements.route)
                    }
                )
            }

            composable(Screen.Schedule.route) {
                ScheduleScreen(viewModel = viewModel)
            }

            composable(Screen.Resources.route) {
                MaterialsScreen(viewModel = viewModel)
            }

            composable(Screen.Announcements.route) {
                AnnouncementsScreen(viewModel = viewModel)
            }

            composable(Screen.Profile.route) {
                ProfileScreen(
                    viewModel = viewModel,
                    onNavigateToBatch = { batchId ->
                        navController.navigate(Screen.BatchDashboard.createRoute(batchId))
                    }
                )
            }

            composable(
                route = Screen.BatchDashboard.route,
                arguments = listOf(
                    navArgument("batchId") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val batchId = backStackEntry.arguments?.getString("batchId") ?: "ai-uses"
                BatchDashboardScreen(
                    batchId = batchId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Global Interactive Dialogs & Modals
    viewingMaterial?.let { material ->
        MaterialViewerDialog(
            material = material,
            onDismiss = { viewModel.closeMaterialViewer() }
        )
    }

    submittingAssignment?.let { assignment ->
        SubmitAssignmentDialog(
            assignment = assignment,
            onDismiss = { viewModel.closeSubmitAssignmentDialog() },
            onSubmit = { text ->
                viewModel.submitAssignment(assignment.id, text)
            }
        )
    }

    selectedClassDetails?.let { courseClass ->
        ClassDetailModal(
            courseClass = courseClass,
            onDismiss = { viewModel.closeClassDetails() }
        )
    }

    if (isEditProfileOpen) {
        EditProfileDialog(
            currentProfile = userProfile,
            onDismiss = { viewModel.setEditProfileOpen(false) },
            onSave = { name, email, phone, bio, avatarColorIndex ->
                viewModel.updateProfile(name, email, phone, bio, avatarColorIndex)
            }
        )
    }
}
