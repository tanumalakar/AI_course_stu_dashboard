package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

interface CourseRepository {
    fun getBatches(): Flow<List<Batch>>
    fun getBatchById(id: String): Flow<Batch?>
    fun getClasses(batchId: String? = null): Flow<List<CourseClass>>
    fun getMaterials(batchId: String? = null, type: MaterialType? = null): Flow<List<MaterialItem>>
    fun getAssignments(batchId: String? = null, status: AssignmentStatus? = null): Flow<List<Assignment>>
    fun getAnnouncements(batchId: String? = null): Flow<List<Announcement>>
    fun getResourceTools(batchId: String? = null): Flow<List<ResourceTool>>
    fun getUserProfile(): Flow<UserProfile>
    suspend fun submitAssignment(assignmentId: String, submissionText: String)
    suspend fun toggleNotificationPreference(enabled: Boolean)
    suspend fun updateProfile(name: String, email: String, phone: String, bio: String, avatarColorIndex: Int = 0)
    suspend fun toggleBatchEnrollment(batchId: String)
}

/**
 * In-Memory reactive repository providing realistic initial batch data.
 * Architecture Note: To switch to Firebase Firestore or a Remote REST API later,
 * simply provide an implementation of [CourseRepository] that reads/writes
 * from FirebaseFirestore.getInstance().collection(...) instead of MutableStateFlow.
 */
class InMemoryCourseRepository : CourseRepository {

    private val batchesFlow = MutableStateFlow(
        listOf(
            Batch(
                id = "ai-uses",
                title = "Artificial Intelligence Uses",
                subtitle = "Applied Generative AI, LLM Workflows & Prompt Engineering",
                description = "Master real-world AI applications: from advanced prompt design and custom agent building to automating workflows with multimodal models and AI coding tools.",
                iconType = "ai",
                instructor = "Dr. Marcus Vance",
                instructorRole = "Lead AI Researcher & Senior Solutions Architect",
                totalClasses = 16,
                completedClasses = 9,
                startDate = "July 15, 2026",
                scheduleDays = "Mon, Wed & Fri",
                timing = "07:00 PM – 08:30 PM EST",
                topics = listOf(
                    "Prompt Engineering Architectures & Zero-Shot/Few-Shot Systems",
                    "Multimodal LLMs (Gemini, GPT-4o, Claude 3.5)",
                    "AI Automation & Autonomous Agents (LangChain, Zapier Central)",
                    "Generative Media Production (Midjourney v6, Stable Diffusion XL)",
                    "AI-Assisted Software Engineering & Code Generation",
                    "Enterprise AI Governance, Security & Bias Mitigation"
                ),
                tools = listOf("Gemini Pro", "ChatGPT Plus", "Claude 3.5", "Midjourney", "Cursor AI", "Hugging Face"),
                enrolledStudentsCount = 52,
                syllabusOverview = "16 comprehensive live sessions structured across 4 progressive modules covering foundational prompt mechanics to production-ready enterprise agent deployment."
            ),
            Batch(
                id = "freelancing",
                title = "Freelancing",
                subtitle = "Global Client Acquisition, High-Ticket Proposals & Scaling",
                description = "Build a profitable international freelancing career. Learn high-converting bidding strategies on Upwork & Fiverr, direct outreach, premium contract negotiation, and agency scaling.",
                iconType = "freelancing",
                instructor = "Sarah Jenkins",
                instructorRole = "Top Rated Plus Freelance Strategist ($400k+ Earned)",
                totalClasses = 14,
                completedClasses = 8,
                startDate = "July 20, 2026",
                scheduleDays = "Tue, Thu & Sat",
                timing = "06:30 PM – 08:00 PM EST",
                topics = listOf(
                    "Niche Specialization & Crafting Your $100/hr Value Proposition",
                    "Upwork & Fiverr Profile Optimization for Top 1% Ranking",
                    "High-Converting Proposal Anatomy & Hook Copywriting",
                    "Milestone Scoping, Pricing Strategy & Escrow Protection",
                    "Handling Difficult Clients, Scope Creep & Retainers",
                    "Global Payment Gateways, Invoicing & Tax Compliance"
                ),
                tools = listOf("Upwork", "Fiverr Pro", "Contra", "Loom", "Wise Business", "Bonsai"),
                enrolledStudentsCount = 64,
                syllabusOverview = "14 actionable workshop-style sessions with live profile audits, personalized proposal feedback, client mock calls, and contracts setup."
            )
        )
    )

    private val classesFlow = MutableStateFlow(
        listOf(
            // AI Uses Batch Classes
            CourseClass(
                id = "ai-cls-10",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                sessionNumber = 10,
                title = "Autonomous Multi-Agent Systems & LangGraph",
                topic = "Building Cooperating AI Agents for Complex Tasks",
                description = "Deep dive into multi-agent loops, state memory, human-in-the-loop validation, and integrating Python tool calling.",
                date = "Aug 14, 2026",
                dayOfWeek = "Friday",
                time = "07:00 PM - 08:30 PM",
                status = ClassStatus.LIVE_NOW,
                meetLink = "https://meet.google.com/ais-class-ai10",
                recordingUrl = null,
                slideNotesUrl = "https://coursecompanion.edu/slides/ai-session-10.pdf"
            ),
            CourseClass(
                id = "ai-cls-11",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                sessionNumber = 11,
                title = "Fine-Tuning vs RAG (Retrieval-Augmented Generation)",
                topic = "Vector Databases & Semantic Search Architecture",
                description = "Comparing embeddings vs direct fine-tuning. Hands-on setup with ChromaDB and document chunking strategies.",
                date = "Aug 17, 2026",
                dayOfWeek = "Monday",
                time = "07:00 PM - 08:30 PM",
                status = ClassStatus.UPCOMING,
                meetLink = "https://meet.google.com/ais-class-ai11"
            ),
            CourseClass(
                id = "ai-cls-12",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                sessionNumber = 12,
                title = "Generative Audio & Video Synthesis",
                topic = "Suno, Runway Gen-3 & ElevenLabs Voice Clones",
                description = "Practical workflows for high-fidelity multimedia synthesis, voiceover automation, and video editing pipelines.",
                date = "Aug 19, 2026",
                dayOfWeek = "Wednesday",
                time = "07:00 PM - 08:30 PM",
                status = ClassStatus.UPCOMING,
                meetLink = "https://meet.google.com/ais-class-ai12"
            ),
            CourseClass(
                id = "ai-cls-9",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                sessionNumber = 9,
                title = "Advanced Prompt Frameworks & System Role Design",
                topic = "Chain-of-Thought, Tree-of-Thought, and XML Tagging",
                description = "Mastering prompt precision, preventing hallucinations, and implementing rigorous evaluation benchmarks.",
                date = "Aug 12, 2026",
                dayOfWeek = "Wednesday",
                time = "07:00 PM - 08:30 PM",
                status = ClassStatus.COMPLETED,
                meetLink = "https://meet.google.com/ais-class-ai09",
                recordingUrl = "https://coursecompanion.edu/recordings/ai-session-09.mp4",
                slideNotesUrl = "https://coursecompanion.edu/slides/ai-session-09.pdf"
            ),
            CourseClass(
                id = "ai-cls-8",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                sessionNumber = 8,
                title = "AI Coding Assistants (Cursor, GitHub Copilot)",
                topic = "Refactoring, Unit Test Generation & Context Prompting",
                description = "Accelerating software workflows by 5x using repository indexing and semantic code diffs.",
                date = "Aug 10, 2026",
                dayOfWeek = "Monday",
                time = "07:00 PM - 08:30 PM",
                status = ClassStatus.COMPLETED,
                meetLink = "https://meet.google.com/ais-class-ai08",
                recordingUrl = "https://coursecompanion.edu/recordings/ai-session-08.mp4",
                slideNotesUrl = "https://coursecompanion.edu/slides/ai-session-08.pdf"
            ),

            // Freelancing Batch Classes
            CourseClass(
                id = "free-cls-9",
                batchId = "freelancing",
                batchName = "Freelancing",
                sessionNumber = 9,
                title = "Mastering Live Client Discovery Calls",
                topic = "The 5-Question Framework to Close High-Ticket Projects",
                description = "Live interactive roleplay sessions on consultative selling, diagnosing client pain points, and closing $3,000+ contracts.",
                date = "Aug 15, 2026",
                dayOfWeek = "Saturday",
                time = "06:30 PM - 08:00 PM",
                status = ClassStatus.UPCOMING,
                meetLink = "https://meet.google.com/ais-class-fr09",
                slideNotesUrl = "https://coursecompanion.edu/slides/fr-session-09.pdf"
            ),
            CourseClass(
                id = "free-cls-10",
                batchId = "freelancing",
                batchName = "Freelancing",
                sessionNumber = 10,
                title = "Crafting Irresistible Value-Based Retainers",
                topic = "Transitioning from Hourly Bidding to Monthly Recurring Revenue",
                description = "How to package ongoing maintenance, monthly optimization, and advisory retainers with enterprise clients.",
                date = "Aug 18, 2026",
                dayOfWeek = "Tuesday",
                time = "06:30 PM - 08:00 PM",
                status = ClassStatus.UPCOMING,
                meetLink = "https://meet.google.com/ais-class-fr10"
            ),
            CourseClass(
                id = "free-cls-8",
                batchId = "freelancing",
                batchName = "Freelancing",
                sessionNumber = 8,
                title = "Winning Upwork Proposal Workshop (Live Audits)",
                topic = "Custom Loom Video Audits & 2-Sentence Hooks",
                description = "Reviewing 10 real student proposals, breaking down why clients respond, and fixing common proposal mistakes.",
                date = "Aug 13, 2026",
                dayOfWeek = "Thursday",
                time = "06:30 PM - 08:00 PM",
                status = ClassStatus.COMPLETED,
                meetLink = "https://meet.google.com/ais-class-fr08",
                recordingUrl = "https://coursecompanion.edu/recordings/fr-session-08.mp4",
                slideNotesUrl = "https://coursecompanion.edu/slides/fr-session-08.pdf"
            ),
            CourseClass(
                id = "free-cls-7",
                batchId = "freelancing",
                batchName = "Freelancing",
                sessionNumber = 7,
                title = "Building a High-Trust Portfolio & Case Studies",
                topic = "Problem-Action-Result Case Study Framework",
                description = "Transforming beginner samples into proof-driven case studies that justify $80+/hr billing rates.",
                date = "Aug 11, 2026",
                dayOfWeek = "Tuesday",
                time = "06:30 PM - 08:00 PM",
                status = ClassStatus.COMPLETED,
                meetLink = "https://meet.google.com/ais-class-fr07",
                recordingUrl = "https://coursecompanion.edu/recordings/fr-session-07.mp4",
                slideNotesUrl = "https://coursecompanion.edu/slides/fr-session-07.pdf"
            )
        )
    )

    private val materialsFlow = MutableStateFlow(
        listOf(
            // AI Materials
            MaterialItem(
                id = "mat-ai-1",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Comprehensive Prompt Engineering Master Handbook",
                type = MaterialType.PDF,
                description = "45-page exhaustive guide with 120+ tested production prompts for reasoning, summarization, JSON formatting, and system constraints.",
                dateAdded = "Aug 10, 2026",
                sizeOrDuration = "8.4 MB PDF",
                tags = listOf("Prompting", "LLMs", "Handbook"),
                isFeatured = true
            ),
            MaterialItem(
                id = "mat-ai-2",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Multi-Agent Automation Pipeline in Python (Colab)",
                type = MaterialType.LINK,
                description = "Ready-to-run Jupyter notebook demonstrating LangGraph state machines and multi-step tool execution.",
                dateAdded = "Aug 12, 2026",
                sizeOrDuration = "Interactive Colab",
                tags = listOf("Python", "Agents", "LangChain"),
                isFeatured = true
            ),
            MaterialItem(
                id = "mat-ai-3",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Session 9 Recording: Advanced Prompt Frameworks",
                type = MaterialType.VIDEO,
                description = "Full 92-minute high-definition recording including Q&A breakdown and live coding demonstrations.",
                dateAdded = "Aug 12, 2026",
                sizeOrDuration = "1h 32m Video",
                tags = listOf("Lecture", "Video", "Session 9")
            ),
            MaterialItem(
                id = "mat-ai-4",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Midjourney v6 Parametric Cheat Sheet & Style Guide",
                type = MaterialType.DOCUMENT,
                description = "Visual cheat sheet with lighting formulas, aspect ratios, seeds, reference images, and negative prompts.",
                dateAdded = "Aug 06, 2026",
                sizeOrDuration = "4.2 MB DOCX",
                tags = listOf("Midjourney", "Design", "Cheatsheet")
            ),

            // Freelancing Materials
            MaterialItem(
                id = "mat-fr-1",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Top 1% Upwork Winning Proposal Scripts (15 Niches)",
                type = MaterialType.PDF,
                description = "Proven proposal templates that have won over $250,000 in contracts across tech, design, writing, and consulting.",
                dateAdded = "Aug 08, 2026",
                sizeOrDuration = "5.1 MB PDF",
                tags = listOf("Upwork", "Proposals", "Templates"),
                isFeatured = true
            ),
            MaterialItem(
                id = "mat-fr-2",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Standard Independent Contractor Agreement & NDA",
                type = MaterialType.DOCUMENT,
                description = "Attorney-reviewed freelance contract template protecting IP rights, milestone schedules, and late payment clauses.",
                dateAdded = "Aug 09, 2026",
                sizeOrDuration = "1.8 MB DOCX",
                tags = listOf("Legal", "Contracts", "NDA"),
                isFeatured = true
            ),
            MaterialItem(
                id = "mat-fr-3",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Hourly vs Fixed-Price Profit Calculator Spreadsheet",
                type = MaterialType.LINK,
                description = "Interactive Google Sheets pricing model to estimate effective hourly rates and calculate taxes/expenses.",
                dateAdded = "Aug 11, 2026",
                sizeOrDuration = "Cloud Spreadsheet",
                tags = listOf("Pricing", "Finance", "Calculator")
            ),
            MaterialItem(
                id = "mat-fr-4",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Session 8 Workshop: Live Proposal Breakdown & Audits",
                type = MaterialType.VIDEO,
                description = "Full 88-minute workshop dissecting 10 student submissions and writing custom personalized pitches live.",
                dateAdded = "Aug 13, 2026",
                sizeOrDuration = "1h 28m Video",
                tags = listOf("Live Audit", "Video", "Session 8")
            )
        )
    )

    private val assignmentsFlow = MutableStateFlow(
        listOf(
            Assignment(
                id = "asg-ai-1",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Build an Automated Research & Summarization Agent",
                description = "Construct a multi-step prompt chain or Python workflow that consumes a 10-page document, extracts key metrics into strict JSON, and produces a 300-word executive summary.",
                dueDate = "Aug 18, 2026",
                daysLeft = 4,
                points = 100,
                status = AssignmentStatus.PENDING,
                requirements = listOf(
                    "Include system prompt with XML delimiters",
                    "Implement fallback error handling for JSON validation",
                    "Submit test inputs and generated sample outputs"
                )
            ),
            Assignment(
                id = "asg-ai-2",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Generative Branding Kit using Diffusion Models",
                description = "Generate a cohesive 4-asset visual set (Logo concept, Hero banner, Social icon, Product mockup) maintaining strict style consistency.",
                dueDate = "Aug 11, 2026",
                daysLeft = 0,
                points = 100,
                status = AssignmentStatus.GRADED,
                submittedAt = "Aug 10, 2026",
                submissionText = "Submitted Midjourney asset link: https://drive.google.com/folders/ai-brand-alex",
                gradeScore = "98 / 100",
                feedback = "Outstanding color consistency and seed control. Excellent prompt composition notes!"
            ),
            Assignment(
                id = "asg-fr-1",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Draft 3 High-Impact Custom Proposals with Video Hooks",
                description = "Select 3 active live job postings on Upwork/Contra in your target niche. Write customized 150-word proposals accompanied by a 60-second Loom script.",
                dueDate = "Aug 19, 2026",
                daysLeft = 5,
                points = 100,
                status = AssignmentStatus.PENDING,
                requirements = listOf(
                    "First 2 lines must address the client's specific bottleneck directly",
                    "Include link to relevant case study sample",
                    "Clear, frictionless Call-to-Action ending"
                )
            ),
            Assignment(
                id = "asg-fr-2",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "100% Upwork Profile Optimization & Video Introduction",
                description = "Complete profile headline, overview bio using the Client-Centric Formula, portfolio project tags, and specialized profile.",
                dueDate = "Aug 12, 2026",
                daysLeft = 0,
                points = 100,
                status = AssignmentStatus.GRADED,
                submittedAt = "Aug 11, 2026",
                submissionText = "Upwork profile URL: upwork.com/freelancers/~01alextech",
                gradeScore = "95 / 100",
                feedback = "Great headline focus and crisp portfolio case studies. Headline stands out in search results!"
            )
        )
    )

    private val announcementsFlow = MutableStateFlow(
        listOf(
            Announcement(
                id = "ann-1",
                batchId = null,
                batchName = "All Batches",
                title = "Mid-Term Project Showcase & Industry Expert Panel",
                date = "Aug 13, 2026",
                timeAgo = "2 hours ago",
                message = "Mark your calendars! On Saturday, Aug 22nd, we will host our combined batch demo day. Top performers will get direct introductions to partner agencies and hiring managers. Detailed rubrics are available in the Resources tab.",
                isPinned = true,
                authorName = "Suhel Rana",
                authorRole = "Course Director",
                priorityTag = "Important"
            ),
            Announcement(
                id = "ann-2",
                batchId = "ai-uses",
                batchName = "Artificial Intelligence Uses",
                title = "Free GPU Cloud Compute Credits Voucher Distributed",
                date = "Aug 12, 2026",
                timeAgo = "1 day ago",
                message = "All enrolled students in the AI Uses batch have been credited with 50 compute hours on our partnered GPU cluster. Check your registered student email for the activation token.",
                isPinned = false,
                authorName = "Dr. Marcus Vance",
                authorRole = "AI Instructor",
                priorityTag = "AI Batch"
            ),
            Announcement(
                id = "ann-3",
                batchId = "freelancing",
                batchName = "Freelancing",
                title = "Live 1-on-1 Profile Audit Slots Available for Booking",
                date = "Aug 11, 2026",
                timeAgo = "2 days ago",
                message = "Sarah has opened 15 additional 15-minute 1-on-1 calendar slots for students who want direct feedback on their Upwork proposals before submitting live bids.",
                isPinned = false,
                authorName = "Sarah Jenkins",
                authorRole = "Freelancing Instructor",
                priorityTag = "Freelancing Batch"
            ),
            Announcement(
                id = "ann-4",
                batchId = null,
                batchName = "All Batches",
                title = "Course Companion Mobile App v1.0 Released",
                date = "Aug 09, 2026",
                timeAgo = "4 days ago",
                message = "Welcome to the native mobile companion app! You can now track your upcoming live classes, access lecture slides, download resource kits, and view assignments all from one unified dashboard.",
                isPinned = false,
                authorName = "Student Success Team",
                authorRole = "Admin",
                priorityTag = "Platform Update"
            )
        )
    )

    private val resourceToolsFlow = MutableStateFlow(
        listOf(
            // AI Tools
            ResourceTool(
                id = "tool-ai-1",
                batchId = "ai-uses",
                name = "Google Gemini 1.5 Pro & Studio",
                category = "Multimodal LLM",
                description = "2M token context window model ideal for processing full codebases, books, and hour-long videos.",
                url = "https://aistudio.google.com",
                badge = "Recommended",
                iconKey = "gemini"
            ),
            ResourceTool(
                id = "tool-ai-2",
                batchId = "ai-uses",
                name = "Cursor AI Code Editor",
                category = "Developer Tooling",
                description = "AI-first IDE with deep repository indexing, multi-file edits, and inline code generation.",
                url = "https://cursor.com",
                badge = "Top Tool",
                iconKey = "code"
            ),
            ResourceTool(
                id = "tool-ai-3",
                batchId = "ai-uses",
                name = "Midjourney v6.1",
                category = "Image Synthesis",
                description = "Leading photorealistic and conceptual diffusion model for creative marketing assets.",
                url = "https://midjourney.com",
                badge = "Creative",
                iconKey = "image"
            ),
            ResourceTool(
                id = "tool-ai-4",
                batchId = "ai-uses",
                name = "Hugging Face Hub",
                category = "Open Source Models",
                description = "Open source hub for exploring Llama 3, Mistral, quantizations, and ML pipelines.",
                url = "https://huggingface.co",
                badge = "Ecosystem",
                iconKey = "hub"
            ),

            // Freelancing Tools
            ResourceTool(
                id = "tool-fr-1",
                batchId = "freelancing",
                name = "Upwork Global Marketplace",
                category = "Job Platform",
                description = "World's largest marketplace for high-paying enterprise contracts and fixed-price projects.",
                url = "https://upwork.com",
                badge = "Primary",
                iconKey = "work"
            ),
            ResourceTool(
                id = "tool-fr-2",
                batchId = "freelancing",
                name = "Contra Independent Portfolio",
                category = "Commission-Free Platform",
                description = "Modern portfolio builder and commission-free contract management for tech freelancers.",
                url = "https://contra.com",
                badge = "0% Fees",
                iconKey = "portfolio"
            ),
            ResourceTool(
                id = "tool-fr-3",
                batchId = "freelancing",
                name = "Loom Async Video Pitching",
                category = "Client Outreach",
                description = "Screen recording tool used to create 60-second personalized audit videos for proposals.",
                url = "https://loom.com",
                badge = "Essential",
                iconKey = "video"
            ),
            ResourceTool(
                id = "tool-fr-4",
                batchId = "freelancing",
                name = "Wise Business Banking",
                category = "Payments & FX",
                description = "Multi-currency accounts to receive USD, EUR, GBP with real mid-market exchange rates.",
                url = "https://wise.com",
                badge = "Financial",
                iconKey = "bank"
            )
        )
    )

    private val userProfileFlow = MutableStateFlow(
        UserProfile()
    )

    override fun getBatches(): Flow<List<Batch>> = batchesFlow.asStateFlow()

    override fun getBatchById(id: String): Flow<Batch?> =
        batchesFlow.map { list -> list.find { it.id == id } }

    override fun getClasses(batchId: String?): Flow<List<CourseClass>> =
        classesFlow.map { list ->
            if (batchId == null) list else list.filter { it.batchId == batchId }
        }

    override fun getMaterials(batchId: String?, type: MaterialType?): Flow<List<MaterialItem>> =
        materialsFlow.map { list ->
            list.filter { item ->
                (batchId == null || item.batchId == batchId) &&
                (type == null || item.type == type)
            }
        }

    override fun getAssignments(batchId: String?, status: AssignmentStatus?): Flow<List<Assignment>> =
        assignmentsFlow.map { list ->
            list.filter { item ->
                (batchId == null || item.batchId == batchId) &&
                (status == null || item.status == status)
            }
        }

    override fun getAnnouncements(batchId: String?): Flow<List<Announcement>> =
        announcementsFlow.map { list ->
            if (batchId == null) list else list.filter { it.batchId == null || it.batchId == batchId }
        }

    override fun getResourceTools(batchId: String?): Flow<List<ResourceTool>> =
        resourceToolsFlow.map { list ->
            if (batchId == null) list else list.filter { it.batchId == batchId }
        }

    override fun getUserProfile(): Flow<UserProfile> = userProfileFlow.asStateFlow()

    override suspend fun submitAssignment(assignmentId: String, submissionText: String) {
        val currentList = assignmentsFlow.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == assignmentId }
        if (index != -1) {
            val updated = currentList[index].copy(
                status = AssignmentStatus.SUBMITTED,
                submittedAt = "Just now",
                submissionText = submissionText
            )
            currentList[index] = updated
            assignmentsFlow.value = currentList

            // Also update completed assignments count in user profile
            val currentProfile = userProfileFlow.value
            val submittedCount = currentList.count { it.status == AssignmentStatus.SUBMITTED || it.status == AssignmentStatus.GRADED }
            val pendingCount = currentList.count { it.status == AssignmentStatus.PENDING }
            userProfileFlow.value = currentProfile.copy(
                completedAssignmentsCount = submittedCount,
                pendingAssignmentsCount = pendingCount
            )
        }
    }

    override suspend fun toggleNotificationPreference(enabled: Boolean) {
        userProfileFlow.value = userProfileFlow.value.copy(notificationEnabled = enabled)
    }

    override suspend fun updateProfile(name: String, email: String, phone: String, bio: String, avatarColorIndex: Int) {
        val initials = name.trim().split(" ")
            .filter { it.isNotEmpty() }
            .mapNotNull { it.firstOrNull()?.uppercaseChar()?.toString() }
            .take(2)
            .joinToString("")
            .ifEmpty { "ST" }

        userProfileFlow.value = userProfileFlow.value.copy(
            name = name,
            email = email,
            phone = phone,
            bio = bio,
            avatarInitials = initials,
            avatarColorIndex = avatarColorIndex
        )
    }

    override suspend fun toggleBatchEnrollment(batchId: String) {
        val currentProfile = userProfileFlow.value
        val currentIds = currentProfile.enrolledBatchIds.toMutableSet()
        val allBatches = batchesFlow.value

        if (currentIds.contains(batchId)) {
            // Unenroll if more than one, or allow empty enrollment
            currentIds.remove(batchId)
        } else {
            currentIds.add(batchId)
        }

        val enrolledBatchTitles = allBatches.filter { it.id in currentIds }.map { it.title }

        // Recalculate stats based on active batch enrollment
        val isAiEnrolled = "ai-uses" in currentIds
        val isFreelanceEnrolled = "freelancing" in currentIds

        val attended = when {
            isAiEnrolled && isFreelanceEnrolled -> 18
            isAiEnrolled -> 10
            isFreelanceEnrolled -> 8
            else -> 0
        }

        val attendanceRate = when {
            isAiEnrolled && isFreelanceEnrolled -> 94
            isAiEnrolled -> 96
            isFreelanceEnrolled -> 92
            else -> 0
        }

        val relevantAssignments = assignmentsFlow.value.filter { it.batchId in currentIds }
        val completed = relevantAssignments.count { it.status == AssignmentStatus.SUBMITTED || it.status == AssignmentStatus.GRADED }
        val pending = relevantAssignments.count { it.status == AssignmentStatus.PENDING }

        val studyHours = when {
            isAiEnrolled && isFreelanceEnrolled -> 46
            isAiEnrolled -> 26
            isFreelanceEnrolled -> 20
            else -> 0
        }

        val weeklyStudyHours = when {
            isAiEnrolled && isFreelanceEnrolled -> 14
            isAiEnrolled -> 8
            isFreelanceEnrolled -> 6
            else -> 0
        }

        userProfileFlow.value = currentProfile.copy(
            enrolledBatchIds = currentIds,
            enrolledBatches = enrolledBatchTitles,
            attendancePercentage = attendanceRate,
            totalClassesAttended = attended,
            completedAssignmentsCount = completed,
            pendingAssignmentsCount = pending,
            studyHoursThisMonth = studyHours,
            studyHoursThisWeek = weeklyStudyHours
        )
    }
}
