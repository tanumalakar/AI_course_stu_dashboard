package com.example.data.model

enum class ClassStatus(val displayName: String) {
    LIVE_NOW("Live Now"),
    UPCOMING("Upcoming"),
    COMPLETED("Completed")
}

enum class MaterialType(val displayName: String) {
    PDF("PDF Document"),
    VIDEO("Video Lecture"),
    DOCUMENT("Notes & Docs"),
    LINK("Interactive Resource")
}

enum class AssignmentStatus(val displayName: String) {
    PENDING("Pending Submission"),
    SUBMITTED("Submitted"),
    GRADED("Graded & Reviewed")
}

data class Batch(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val iconType: String,
    val instructor: String,
    val instructorRole: String,
    val totalClasses: Int,
    val completedClasses: Int,
    val startDate: String,
    val scheduleDays: String,
    val timing: String,
    val progress: Float = completedClasses.toFloat() / totalClasses.toFloat(),
    val topics: List<String>,
    val tools: List<String>,
    val enrolledStudentsCount: Int = 48,
    val syllabusOverview: String
)

data class CourseClass(
    val id: String,
    val batchId: String,
    val batchName: String,
    val sessionNumber: Int,
    val title: String,
    val topic: String,
    val description: String,
    val date: String,
    val dayOfWeek: String,
    val time: String,
    val durationMinutes: Int = 90,
    val status: ClassStatus,
    val meetLink: String = "https://meet.google.com/ais-class-live",
    val recordingUrl: String? = null,
    val slideNotesUrl: String? = null,
    val resourcesAttachedCount: Int = 3
)

data class MaterialItem(
    val id: String,
    val batchId: String,
    val batchName: String,
    val title: String,
    val type: MaterialType,
    val description: String,
    val dateAdded: String,
    val sizeOrDuration: String,
    val url: String = "https://learning.coursecompanion.edu/resources",
    val tags: List<String> = emptyList(),
    val isFeatured: Boolean = false
)

data class Assignment(
    val id: String,
    val batchId: String,
    val batchName: String,
    val title: String,
    val description: String,
    val dueDate: String,
    val daysLeft: Int,
    val points: Int = 100,
    val status: AssignmentStatus,
    val submittedAt: String? = null,
    val submissionText: String? = null,
    val gradeScore: String? = null,
    val feedback: String? = null,
    val requirements: List<String> = emptyList()
)

data class Announcement(
    val id: String,
    val batchId: String?, // null means All batches
    val batchName: String?,
    val title: String,
    val date: String,
    val timeAgo: String,
    val message: String,
    val isPinned: Boolean = false,
    val authorName: String = "Course Coordinator",
    val authorRole: String = "Instructor & Lead",
    val priorityTag: String = "Announcement"
)

data class ResourceTool(
    val id: String,
    val batchId: String,
    val name: String,
    val category: String,
    val description: String,
    val url: String,
    val badge: String,
    val iconKey: String
)

data class UserProfile(
    val name: String = "Alex Johnson",
    val studentId: String = "CC-2026-8492",
    val email: String = "alex.johnson@student.companion.edu",
    val phone: String = "+1 (555) 382-9104",
    val avatarInitials: String = "AJ",
    val avatarColorIndex: Int = 0,
    val enrolledBatches: List<String> = listOf("Artificial Intelligence Uses", "Freelancing"),
    val enrolledBatchIds: Set<String> = setOf("ai-uses", "freelancing"),
    val attendancePercentage: Int = 94,
    val totalClassesAttended: Int = 18,
    val completedAssignmentsCount: Int = 7,
    val pendingAssignmentsCount: Int = 2,
    val studyHoursThisMonth: Int = 46,
    val studyHoursThisWeek: Int = 14,
    val notificationEnabled: Boolean = true,
    val bio: String = "Aspiring AI Specialist & Freelance Tech Consultant aiming to build high-impact autonomous workflows and secure international client contracts."
)
